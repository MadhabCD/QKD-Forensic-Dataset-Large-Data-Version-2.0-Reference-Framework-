"""
generate_classical_data.py

Classical data generator for QKD-Forensic Dataset V2.0

Outputs:
  data/raw/classical/<scenario>.csv

Notes:
- Run from project root:
    python scripts/classical/generate_classical_data.py
- Uses config/global_config.yaml for reproducibility.
- Time alignment rule:
    timestamp + scenario must match quantum stream for fusion.
"""

import csv
from pathlib import Path

import numpy as np

from scripts.utils.config_loader import load_config


def clamp(x: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, x))


def get_project_root() -> Path:
    return Path(__file__).resolve().parents[2]


def sample_normal(rng: np.random.Generator) -> dict:
    """
    Normal operation classical measurements (per second).
    """
    rtt = clamp(rng.normal(18.0, 4.0), 1.0, 120.0)  # ms
    packet_loss = clamp(rng.normal(0.002, 0.002), 0.0, 0.08)  # ratio
    throughput = clamp(rng.normal(12000.0, 2500.0), 500.0, 40000.0)  # bytes/sec

    # retransmissions correlate with packet loss
    lam = 0.2 + 15.0 * packet_loss
    retransmit = int(max(0, rng.poisson(lam)))

    sync_offset = clamp(rng.normal(0.8, 0.6), 0.0, 25.0)  # ms

    return {
        "rtt": float(rtt),
        "packet_loss": float(packet_loss),
        "throughput": float(throughput),
        "retransmit": retransmit,
        "sync_offset": float(sync_offset),
    }


def sample_eavesdrop(rng: np.random.Generator) -> dict:
    """
    Eavesdropping: classical indicators are mostly subtle.
    """
    d = sample_normal(rng)
    d["rtt"] = float(clamp(d["rtt"] + rng.normal(1.5, 2.0), 1.0, 180.0))
    d["packet_loss"] = float(clamp(d["packet_loss"] + rng.normal(0.001, 0.002), 0.0, 0.10))
    d["throughput"] = float(clamp(d["throughput"] * rng.uniform(0.95, 1.05), 500.0, 50000.0))
    # retransmit will remain consistent via small packet_loss bump
    d["retransmit"] = int(max(0, rng.poisson(0.2 + 15.0 * d["packet_loss"])))
    return d


def sample_degradation(rng: np.random.Generator, alpha: float) -> dict:
    """
    Channel degradation (benign): RTT increases, packet loss rises, throughput drops.
    alpha in [0,1] indicates progression over time.
    """
    d = sample_normal(rng)

    d["rtt"] = float(clamp(d["rtt"] + (30.0 * alpha) + rng.normal(0.0, 3.0), 1.0, 300.0))
    d["packet_loss"] = float(clamp(d["packet_loss"] + rng.normal(0.01 * alpha, 0.003), 0.0, 0.30))
    d["throughput"] = float(clamp(d["throughput"] * clamp(1.0 - 0.55 * alpha + rng.normal(0.0, 0.03), 0.10, 1.10),
                                  200.0, 50000.0))
    d["retransmit"] = int(max(0, rng.poisson(0.3 + 20.0 * d["packet_loss"])))

    # small drift may occur but not extreme
    d["sync_offset"] = float(clamp(d["sync_offset"] + rng.normal(0.6 * alpha, 0.6), 0.0, 60.0))
    return d


def sample_dos(rng: np.random.Generator) -> dict:
    """
    DoS: RTT spikes, packet loss high, throughput collapses, retransmits frequent.
    """
    d = sample_normal(rng)

    d["rtt"] = float(clamp(rng.normal(220.0, 80.0), 20.0, 800.0))
    d["packet_loss"] = float(clamp(rng.normal(0.35, 0.12), 0.05, 0.95))
    d["throughput"] = float(clamp(rng.normal(900.0, 700.0), 0.0, 8000.0))
    d["retransmit"] = int(max(0, rng.poisson(3.0 + 40.0 * d["packet_loss"])))

    d["sync_offset"] = float(clamp(rng.normal(8.0, 6.0), 0.0, 200.0))
    return d


def sample_misconfig(rng: np.random.Generator) -> dict:
    """
    Misconfiguration/timing drift: persistent offset and mild instability.
    """
    d = sample_normal(rng)

    # stable but biased sync offset
    d["sync_offset"] = float(clamp(rng.normal(18.0, 4.0), 2.0, 80.0))

    # mild RTT and loss instability
    d["rtt"] = float(clamp(d["rtt"] + rng.normal(6.0, 3.0), 1.0, 250.0))
    d["packet_loss"] = float(clamp(d["packet_loss"] + rng.normal(0.015, 0.006), 0.0, 0.35))
    d["throughput"] = float(clamp(d["throughput"] * rng.uniform(0.85, 0.98), 100.0, 50000.0))
    d["retransmit"] = int(max(0, rng.poisson(0.6 + 25.0 * d["packet_loss"])))

    return d


def generate_scenario(scenario: str, duration_sec: int, seed: int, out_dir: Path) -> None:
    out_dir.mkdir(parents=True, exist_ok=True)
    out_path = out_dir / f"{scenario}.csv"

    # scenario-specific deterministic seed
    scenario_seed = seed + (abs(hash("classical:" + scenario)) % 10000)
    rng = np.random.default_rng(scenario_seed)

    header = ["timestamp", "scenario", "rtt", "packet_loss", "throughput", "retransmit", "sync_offset"]

    with out_path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(header)

        for t in range(duration_sec):
            if scenario == "normal":
                d = sample_normal(rng)
            elif scenario == "eavesdrop":
                d = sample_eavesdrop(rng)
            elif scenario == "degradation":
                alpha = t / max(1, duration_sec - 1)
                d = sample_degradation(rng, alpha)
            elif scenario == "dos":
                d = sample_dos(rng)
            elif scenario == "misconfig":
                d = sample_misconfig(rng)
            else:
                raise ValueError(f"Unknown scenario: {scenario}")

            writer.writerow([t, scenario, d["rtt"], d["packet_loss"], d["throughput"], d["retransmit"], d["sync_offset"]])

    print(f"[OK] Classical scenario generated: {out_path}  (rows={duration_sec})")


def main() -> None:
    cfg = load_config()

    seed = int(cfg.get("seed_value", 42))
    sampling_interval = int(cfg.get("sampling_interval_sec", 1))
    if sampling_interval != 1:
        raise ValueError("This generator expects sampling_interval_sec = 1 for V2.0.")

    durations = cfg.get("duration", {})
    normal_sec = int(durations.get("normal_sec", 10800))
    attack_sec = int(durations.get("attack_sec", 7200))

    scenarios = cfg.get("scenarios", ["normal", "eavesdrop", "degradation", "dos", "misconfig"])

    project_root = get_project_root()
    out_dir = project_root / "data" / "raw" / "classical"

    for s in scenarios:
        dur = normal_sec if s == "normal" else attack_sec
        generate_scenario(s, dur, seed, out_dir)


if __name__ == "__main__":
    main()
