"""
generate_quantum_data.py

Quantum data generator for QKD-Forensic Dataset V2.0

Outputs:
  data/raw/quantum/<scenario>.csv

Notes:
- Run from project root:
    python scripts/quantum/generate_quantum_data.py
- Uses config/global_config.yaml for reproducibility.
"""

import csv
from pathlib import Path

import numpy as np

from scripts.utils.config_loader import load_config


def clamp(x: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, x))


def get_project_root() -> Path:
    return Path(__file__).resolve().parents[2]


def sample_normal(rng: np.random.Generator) -> dict:
    """
    Normal operation quantum measurements (per second).
    """
    qber = clamp(rng.normal(0.015, 0.004), 0.0, 0.15)
    photon_rate = float(max(0, rng.poisson(rng.uniform(50000, 90000))))
    decoy_ratio = clamp(rng.normal(0.22, 0.03), 0.01, 0.60)

    # key_rate: positive with photon_rate, negative with qber
    base_key = photon_rate * rng.uniform(0.10, 0.18)
    key_rate = max(0.0, base_key * (1.0 - 8.0 * qber))

    return {
        "qber": qber,
        "photon_rate": photon_rate,
        "decoy_ratio": decoy_ratio,
        "key_rate": float(key_rate),
    }


def sample_eavesdrop(rng: np.random.Generator) -> dict:
    """
    Eavesdropping (intercept-resend style): QBER increases, key_rate decreases.
    """
    d = sample_normal(rng)
    d["qber"] = clamp(rng.normal(0.18, 0.03), 0.06, 0.35)
    d["decoy_ratio"] = clamp(d["decoy_ratio"] * rng.uniform(0.85, 1.20), 0.01, 0.70)

    # heavily suppress key rate
    d["key_rate"] = float(max(0.0, d["key_rate"] * rng.uniform(0.0, 0.15)))
    return d


def sample_degradation(rng: np.random.Generator, alpha: float) -> dict:
    """
    Channel degradation (benign): photon_rate decreases gradually, QBER increases moderately.
    alpha in [0,1] represents progression over time.
    """
    d = sample_normal(rng)

    # photon_rate drop over time
    drop = clamp(1.0 - 0.65 * alpha + rng.normal(0.0, 0.03), 0.05, 1.0)
    d["photon_rate"] = float(d["photon_rate"] * drop)

    # QBER moderate increase
    d["qber"] = clamp(d["qber"] + rng.normal(0.03 * alpha, 0.008), 0.0, 0.25)

    # update key rate accordingly
    base_key = d["photon_rate"] * 0.14
    d["key_rate"] = float(max(0.0, base_key * (1.0 - 8.0 * d["qber"])))

    return d


def sample_dos(rng: np.random.Generator) -> dict:
    """
    DoS: photon_rate collapses, key_rate near zero, qber becomes unstable.
    """
    d = sample_normal(rng)
    d["photon_rate"] = float(max(0.0, d["photon_rate"] * rng.uniform(0.0, 0.08)))
    d["qber"] = clamp(rng.normal(0.10, 0.06), 0.0, 0.5)
    d["decoy_ratio"] = clamp(rng.normal(0.18, 0.08), 0.01, 0.80)
    d["key_rate"] = float(max(0.0, d["photon_rate"] * rng.uniform(0.0, 0.02)))
    return d


def sample_misconfig(rng: np.random.Generator) -> dict:
    """
    Misconfiguration / timing drift: subtle persistent shifts.
    """
    d = sample_normal(rng)
    d["qber"] = clamp(d["qber"] + rng.normal(0.02, 0.01), 0.0, 0.25)
    d["decoy_ratio"] = clamp(d["decoy_ratio"] + rng.normal(0.06, 0.02), 0.01, 0.90)
    base_key = d["photon_rate"] * 0.13
    d["key_rate"] = float(max(0.0, base_key * (1.0 - 8.0 * d["qber"])))
    return d


def generate_scenario(scenario: str, duration_sec: int, seed: int, out_dir: Path) -> None:
    """
    Generate one scenario CSV file.
    """
    out_dir.mkdir(parents=True, exist_ok=True)
    out_path = out_dir / f"{scenario}.csv"

    # scenario-specific deterministic seed
    scenario_seed = seed + (abs(hash(scenario)) % 10000)
    rng = np.random.default_rng(scenario_seed)

    header = ["timestamp", "scenario", "qber", "photon_rate", "decoy_ratio", "key_rate"]

    with out_path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(header)

        for t in range(duration_sec):
            if scenario == "normal":
                d = sample_normal(rng)
            elif scenario == "eavesdrop":
                d = sample_eavesdrop(rng)
            elif scenario == "degradation":
                alpha = t / max(1, duration_sec - 1)
                d = sample_degradation(rng, alpha)
            elif scenario == "dos":
                d = sample_dos(rng)
            elif scenario == "misconfig":
                d = sample_misconfig(rng)
            else:
                raise ValueError(f"Unknown scenario: {scenario}")

            writer.writerow([t, scenario, d["qber"], d["photon_rate"], d["decoy_ratio"], d["key_rate"]])

    print(f"[OK] Quantum scenario generated: {out_path}  (rows={duration_sec})")


def main() -> None:
    cfg = load_config()

    seed = int(cfg.get("seed_value", 42))
    sampling_interval = int(cfg.get("sampling_interval_sec", 1))
    if sampling_interval != 1:
        raise ValueError("This generator expects sampling_interval_sec = 1 for V2.0.")

    durations = cfg.get("duration", {})
    normal_sec = int(durations.get("normal_sec", 10800))
    attack_sec = int(durations.get("attack_sec", 7200))

    scenarios = cfg.get("scenarios", ["normal", "eavesdrop", "degradation", "dos", "misconfig"])

    project_root = get_project_root()
    out_dir = project_root / "data" / "raw" / "quantum"

    for s in scenarios:
        dur = normal_sec if s == "normal" else attack_sec
        generate_scenario(s, dur, seed, out_dir)


if __name__ == "__main__":
    main()
