"""
fuse_streams.py

Fuses quantum and classical streams for QKD-Forensic Dataset V2.0.

Inputs:
  data/raw/quantum/<scenario>.csv
  data/raw/classical/<scenario>.csv

Outputs:
  data/processed/fused/<scenario>_fused.csv

Join rule:
  Inner join on (timestamp, scenario)
"""

import csv
from pathlib import Path
from typing import Dict, List

from scripts.utils.config_loader import load_config


def get_project_root() -> Path:
    return Path(__file__).resolve().parents[2]


def read_csv_as_dict(path: Path, key_fields: List[str]) -> Dict[tuple, Dict[str, str]]:
    """
    Read a CSV and index rows by tuple key_fields.

    Returns:
        mapping: (key_fields tuple) -> full row dict
    """
    mapping: Dict[tuple, Dict[str, str]] = {}
    with path.open("r", encoding="utf-8", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            key = tuple(row[k] for k in key_fields)
            mapping[key] = row
    return mapping


def fuse_one_scenario(scenario: str, root: Path) -> Path:
    quantum_path = root / "data" / "raw" / "quantum" / f"{scenario}.csv"
    classical_path = root / "data" / "raw" / "classical" / f"{scenario}.csv"

    if not quantum_path.exists():
        raise FileNotFoundError(f"Missing quantum file: {quantum_path}")
    if not classical_path.exists():
        raise FileNotFoundError(f"Missing classical file: {classical_path}")

    q_map = read_csv_as_dict(quantum_path, key_fields=["timestamp", "scenario"])
    c_map = read_csv_as_dict(classical_path, key_fields=["timestamp", "scenario"])

    common_keys = sorted(set(q_map.keys()) & set(c_map.keys()), key=lambda k: int(k[0]))

    out_dir = root / "data" / "processed" / "fused"
    out_dir.mkdir(parents=True, exist_ok=True)
    out_path = out_dir / f"{scenario}_fused.csv"

    # Build fused header: metadata + quantum features + classical features
    q_fields = [f for f in q_map[common_keys[0]].keys() if f not in ("timestamp", "scenario")]
    c_fields = [f for f in c_map[common_keys[0]].keys() if f not in ("timestamp", "scenario")]

    header = ["timestamp", "scenario"] + q_fields + c_fields

    with out_path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=header)
        writer.writeheader()

        for k in common_keys:
            q = q_map[k]
            c = c_map[k]

            fused = {"timestamp": q["timestamp"], "scenario": q["scenario"]}
            for f_q in q_fields:
                fused[f_q] = q[f_q]
            for f_c in c_fields:
                fused[f_c] = c[f_c]

            writer.writerow(fused)

    print(f"[OK] Fused scenario created: {out_path}  (rows={len(common_keys)})")
    return out_path


def main() -> None:
    cfg = load_config()
    scenarios = cfg.get("scenarios", ["normal", "eavesdrop", "degradation", "dos", "misconfig"])

    root = get_project_root()
    for s in scenarios:
        fuse_one_scenario(s, root)


if __name__ == "__main__":
    main()
