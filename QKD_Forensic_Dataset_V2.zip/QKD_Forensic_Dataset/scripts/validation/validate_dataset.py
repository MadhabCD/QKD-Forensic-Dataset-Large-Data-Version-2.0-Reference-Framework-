"""
validate_dataset.py

Validation script for QKD-Forensic Dataset V2.0.

Validates:
- raw quantum CSVs
- raw classical CSVs
- fused CSVs

Checks:
- required columns exist
- scenario labels are correct
- timestamps start at 0 and increase by 1
- row count matches config durations
"""

from pathlib import Path
from typing import List, Set

import pandas as pd

from scripts.utils.config_loader import load_config


def get_project_root() -> Path:
    return Path(__file__).resolve().parents[2]


def require_columns(df: pd.DataFrame, cols: List[str], file_path: Path) -> None:
    missing = [c for c in cols if c not in df.columns]
    if missing:
        raise ValueError(f"Missing columns {missing} in {file_path}")


def check_timestamps(df: pd.DataFrame, file_path: Path) -> None:
    if "timestamp" not in df.columns:
        raise ValueError(f"No 'timestamp' column in {file_path}")

    ts = df["timestamp"].astype(int).to_numpy()
    if len(ts) == 0:
        raise ValueError(f"Empty file: {file_path}")

    if ts[0] != 0:
        raise ValueError(f"timestamp must start at 0 in {file_path}, got {ts[0]}")

    # verify consecutive increments
    diffs = ts[1:] - ts[:-1]
    if len(diffs) > 0 and (diffs != 1).any():
        bad_idx = int((diffs != 1).nonzero()[0][0])
        raise ValueError(
            f"timestamp must be consecutive in {file_path}. "
            f"Found break at row {bad_idx}->{bad_idx+1}: {ts[bad_idx]} to {ts[bad_idx+1]}"
        )


def check_scenario_labels(df: pd.DataFrame, allowed: Set[str], file_path: Path) -> None:
    if "scenario" not in df.columns:
        raise ValueError(f"No 'scenario' column in {file_path}")

    unique = set(df["scenario"].astype(str).unique().tolist())
    unknown = unique - allowed
    if unknown:
        raise ValueError(f"Unknown scenario labels {sorted(list(unknown))} in {file_path}")


def validate_raw_quantum(path: Path, scenario: str, expected_rows: int, allowed: Set[str]) -> None:
    df = pd.read_csv(path)
    require_columns(df, ["timestamp", "scenario", "qber", "photon_rate", "decoy_ratio", "key_rate"], path)
    check_timestamps(df, path)
    check_scenario_labels(df, allowed, path)

    # scenario consistency
    if set(df["scenario"].unique()) != {scenario}:
        raise ValueError(f"Scenario column mismatch in {path}. Expected only '{scenario}'.")

    if len(df) != expected_rows:
        raise ValueError(f"Row count mismatch in {path}. Expected {expected_rows}, got {len(df)}.")


def validate_raw_classical(path: Path, scenario: str, expected_rows: int, allowed: Set[str]) -> None:
    df = pd.read_csv(path)
    require_columns(df, ["timestamp", "scenario", "rtt", "packet_loss", "throughput", "retransmit", "sync_offset"], path)
    check_timestamps(df, path)
    check_scenario_labels(df, allowed, path)

    if set(df["scenario"].unique()) != {scenario}:
        raise ValueError(f"Scenario column mismatch in {path}. Expected only '{scenario}'.")

    if len(df) != expected_rows:
        raise ValueError(f"Row count mismatch in {path}. Expected {expected_rows}, got {len(df)}.")


def validate_fused(path: Path, scenario: str, expected_rows: int, allowed: Set[str]) -> None:
    df = pd.read_csv(path)
    require_columns(df, ["timestamp", "scenario"], path)
    check_timestamps(df, path)
    check_scenario_labels(df, allowed, path)

    if set(df["scenario"].unique()) != {scenario}:
        raise ValueError(f"Scenario column mismatch in {path}. Expected only '{scenario}'.")

    if len(df) != expected_rows:
        raise ValueError(f"Row count mismatch in {path}. Expected {expected_rows}, got {len(df)}.")


def main() -> None:
    cfg = load_config()

    durations = cfg.get("duration", {})
    normal_sec = int(durations.get("normal_sec", 10800))
    attack_sec = int(durations.get("attack_sec", 7200))

    scenarios = cfg.get("scenarios", ["normal", "eavesdrop", "degradation", "dos", "misconfig"])
    allowed = set(scenarios)

    root = get_project_root()

    quantum_dir = root / "data" / "raw" / "quantum"
    classical_dir = root / "data" / "raw" / "classical"
    fused_dir = root / "data" / "processed" / "fused"

    print("=== VALIDATION START ===")
    print(f"Project root: {root}")
    print(f"Scenarios: {scenarios}")

    for s in scenarios:
        expected = normal_sec if s == "normal" else attack_sec

        q_path = quantum_dir / f"{s}.csv"
        c_path = classical_dir / f"{s}.csv"
        f_path = fused_dir / f"{s}_fused.csv"

        if q_path.exists():
            validate_raw_quantum(q_path, s, expected, allowed)
            print(f"[OK] Quantum validated: {q_path.name}")
        else:
            print(f"[WARN] Quantum missing: {q_path}")

        if c_path.exists():
            validate_raw_classical(c_path, s, expected, allowed)
            print(f"[OK] Classical validated: {c_path.name}")
        else:
            print(f"[WARN] Classical missing: {c_path}")

        if f_path.exists():
            validate_fused(f_path, s, expected, allowed)
            print(f"[OK] Fused validated: {f_path.name}")
        else:
            print(f"[WARN] Fused missing: {f_path}")

    print("=== VALIDATION COMPLETE ===")


if __name__ == "__main__":
    main()
