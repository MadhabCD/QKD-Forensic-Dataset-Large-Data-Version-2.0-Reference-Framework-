"""
config_loader.py

Utility for loading the dataset configuration (YAML) in a reproducible way.

Expected location:
  <project_root>/config/global_config.yaml
"""

from pathlib import Path
from typing import Any, Dict

import yaml


def get_project_root() -> Path:
    """
    Returns the project root directory by navigating two levels up from:
      scripts/utils/config_loader.py  -> project_root
    """
    return Path(__file__).resolve().parents[2]


def load_config() -> Dict[str, Any]:
    """
    Load configuration from config/global_config.yaml.

    Returns:
        dict: Parsed YAML config.

    Raises:
        FileNotFoundError: If global_config.yaml is missing.
        ValueError: If YAML is invalid or empty.
    """
    project_root = get_project_root()
    config_path = project_root / "config" / "global_config.yaml"

    if not config_path.exists():
        raise FileNotFoundError(f"Config file not found: {config_path}")

    with config_path.open("r", encoding="utf-8") as f:
        cfg = yaml.safe_load(f)

    if not isinstance(cfg, dict) or not cfg:
        raise ValueError(f"Invalid or empty YAML config: {config_path}")

    return cfg
