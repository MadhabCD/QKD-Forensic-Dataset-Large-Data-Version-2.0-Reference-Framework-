"""
random_seed.py

Centralized random seed handling for reproducible dataset generation.
"""

import numpy as np


def set_global_seed(seed_value: int) -> None:
    """
    Set global random seed for numpy-based randomness.

    Args:
        seed_value (int): Seed value for reproducibility.
    """
    np.random.seed(seed_value)
