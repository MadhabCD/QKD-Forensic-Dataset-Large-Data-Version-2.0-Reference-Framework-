## Dataset Access Notice

The official QKD-Forensic Dataset Version 2.0 (200K samples)
is NOT stored in this GitHub repository.

Due to size, integrity, and citation requirements, the dataset
is distributed exclusively via Zenodo.

Please download the dataset from:
https://doi.org/10.5281/zenodo.17773084 (Version 1.0)
Version 2.0 DOI will be provided upon release.

This repository provides reference scripts, documentation,
and validation tools only.
