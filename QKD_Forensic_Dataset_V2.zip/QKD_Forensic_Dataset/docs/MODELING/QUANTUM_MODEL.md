# Quantum-Layer Modeling Assumptions — QKD-Forensic Dataset V2.0

This document defines the modeling assumptions used to generate
quantum-layer measurements in the QKD-Forensic Dataset V2.0.

The goal is to produce realistic, time-indexed quantum behavior
suitable for anomaly and intrusion detection research.

---

## 1. Protocol Scope

- Protocol family: BB84 with decoy-state extensions
- Perspective: Operational monitoring (not protocol proof security)
- Abstraction level:
  - Physical-layer effects are modeled statistically
  - No quantum state simulation is performed

This design prioritizes:
- Reproducibility
- Scalability
- ML compatibility

---

## 2. Core Quantum Features

The following quantum-layer features are generated per second:

- **QBER**
  - Definition: Ratio of erroneous bits to total detected bits
  - Range: [0, 1]

- **Photon Count Rate**
  - Definition: Detected photon events per second
  - Units: counts/sec

- **Decoy-State Response Ratio**
  - Definition: Ratio of decoy detections to signal detections
  - Dimensionless

- **Key Generation Rate**
  - Definition: Estimated secure key bits per second
  - Units: bits/sec

Each feature is generated independently per second,
subject to scenario-specific constraints.

---

## 3. Normal Operation Model

Under normal conditions:

- QBER:
  - Low mean value
  - Small variance
  - Temporally stable

- Photon count rate:
  - Stable around a nominal mean
  - Minor stochastic fluctuations

- Decoy response:
  - Consistent ratio across time
  - No abrupt deviations

- Key rate:
  - Positively correlated with count rate
  - Negatively correlated with QBER

These behaviors represent a healthy QKD link.

---

## 4. Attack and Fault Scenarios

Each scenario modifies the baseline behavior in a controlled manner.

### 4.1 Eavesdropping Scenario

- Increased QBER
- Reduced key generation rate
- Mild perturbation in decoy response
- Gradual temporal drift rather than abrupt spikes

### 4.2 Channel Degradation Scenario

- Moderate QBER increase
- Reduced photon count rate
- Decoy response remains largely stable
- Represents benign physical-layer faults

### 4.3 Denial-of-Service Scenario

- Sharp drop in photon count rate
- Near-zero key generation rate
- QBER may become unstable or undefined
- High variance across time

### 4.4 Misconfiguration Scenario

- Subtle but persistent deviations
- Timing-related instabilities
- Feature shifts that resemble neither attack nor noise

---

## 5. Temporal Structure

- Sampling interval: 1 second
- Each second is modeled independently
- Temporal correlations emerge statistically across time
- No explicit sequence model is imposed during generation

This ensures compatibility with:
- Sliding-window ML models
- Sequence-based deep learning
- Change-point detection

---

## 6. Labeling Policy

- Each row is labeled with a single scenario class
- Labels are scenario-consistent across time
- No mixed or ambiguous labels are introduced

Labeling is deterministic and reproducible.

---

## 7. Limitations

- This dataset does not simulate quantum states or wavefunctions
- Physical
