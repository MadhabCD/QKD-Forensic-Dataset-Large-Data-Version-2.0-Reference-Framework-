# Classical-Layer Modeling Assumptions — QKD-Forensic Dataset V2.0

This document defines the modeling assumptions used to generate
classical communication and system-level measurements in the
QKD-Forensic Dataset V2.0.

These features represent the operational context surrounding
a QKD deployment and are designed to complement quantum-layer signals.

---

## 1. Scope of Classical Measurements

Classical-layer measurements abstract observable behavior from:

- Control-channel communication
- Network transport characteristics
- System and protocol operation status

The modeling focuses on **behavioral indicators**, not packet contents.

---

## 2. Core Classical Features

The following classical features are generated per second:

- **Round-Trip Time (RTT)**
  - Definition: Control message response latency
  - Units: milliseconds

- **Packet Loss Rate**
  - Definition: Fraction of lost control packets per second
  - Range: [0, 1]

- **Throughput**
  - Definition: Control-channel data volume per second
  - Units: bytes/sec

- **Retransmission Count**
  - Definition: Number of retransmissions per second
  - Units: count/sec

- **Synchronization Offset**
  - Definition: Timing drift between endpoints
  - Units: milliseconds

Each feature is generated independently per second
subject to scenario-specific constraints.

---

## 3. Normal Operation Model

Under normal conditions:

- RTT:
  - Stable mean
  - Low variance
  - No persistent spikes

- Packet loss:
  - Near-zero
  - Occasional random drops

- Throughput:
  - Consistent with protocol overhead
  - Minor stochastic variation

- Retransmissions:
  - Rare events
  - Correlated with packet loss

- Synchronization offset:
  - Small bounded drift
  - Corrected periodically

These behaviors represent a healthy control channel.

---

## 4. Attack and Fault Scenarios

Scenario-specific deviations are introduced
while preserving internal consistency.

### 4.1 Eavesdropping Scenario

- Minimal classical anomalies
- Slight increase in RTT variance
- Occasional retransmissions
- Reflects stealthy behavior

### 4.2 Channel Degradation Scenario

- Increased RTT
- Elevated packet loss
- Reduced throughput
- Benign physical or environmental issues

### 4.3 Denial-of-Service Scenario

- Large RTT spikes
- High packet loss
- Throughput collapse
- Frequent retransmissions

This scenario produces strong classical indicators.

### 4.4 Misconfiguration Scenario

- Persistent synchronization offset
- Mild RTT instability
- Non-random, long-term deviations
- Difficult to distinguish from noise

---

## 5. Temporal Characteristics

- Sampling interval: 1 second
- No explicit temporal smoothing
- Short-term variability is preserved

This enables:
- Sliding-window analysis
- Burst detection
- Change-point detection

---

## 6. Correlation with Quantum Layer

Classical features are designed to be:

- Weakly correlated with quantum features under normal operation
- Strongly correlated under certain attacks (e.g., DoS)
- Complementary rather than redundant

This supports cross-layer fusion and joint modeling.

---

## 7. Labeling Policy

- Classical data inherits scenario labels
- Labels are consistent across time
- No feature-driven relabeling is applied

---

## 8. Limitations

- No packet-level simulation
- No protocol-specific message parsing
- Values represent abstractions, not raw captures

The focus is on **behavioral modeling**, not traffic emulation.

---

## 9. Intended Use

Classical-layer features are intended for:

- Context-aware anomaly detection
- Intrusion detection research
- Cross-layer fusion with quantum features

They are not intended for forensic reconstruction of network traffic.

---

## 10. Summary

- Classical behavior is statistically modeled
- Time-indexed at 1-second resolution
- Scenario-specific deviations are controlled
- Designed to complement quantum-layer signals
