# Unified Feature Table — QKD-Forensic Dataset V2.0

This document defines the complete and authoritative list of features
used in the QKD-Forensic Dataset V2.0.

All features are time-indexed at a 1-second resolution and are designed
for reproducible anomaly and intrusion detection research.

---

## 1. Common Metadata

| Feature Name | Type    | Description |
|-------------|---------|-------------|
| timestamp   | Integer | Time index in seconds from the start of a scenario |
| scenario    | String  | Scenario label (normal, eavesdrop, degradation, dos, misconfig) |

---

## 2. Quantum-Layer Features

| Feature Name | Type  | Unit        | Description |
|-------------|-------|-------------|-------------|
| qber        | Float | Ratio       | Quantum Bit Error Rate per second |
| photon_rate| Float | counts/sec  | Detected photon events per second |
| decoy_ratio| Float | Ratio       | Decoy-state detection ratio |
| key_rate   | Float | bits/sec    | Estimated secure key generation rate |

---

## 3. Classical-Layer Features

| Feature Name | Type  | Unit        | Description |
|-------------|-------|-------------|-------------|
| rtt         | Float | milliseconds| Control-channel round-trip time |
| packet_loss| Float | Ratio       | Fraction of lost control packets |
| throughput | Float | bytes/sec   | Control-channel data throughput |
| retransmit | Integer | count/sec  | Number of retransmissions |
| sync_offset| Float | milliseconds| Timing drift between endpoints |

---

## 4. Feature Generation Properties

- All features are generated **per second**
- No missing values are introduced
- All numerical features are continuous except:
  - `timestamp`
  - `scenario`
  - `retransmit`

---

## 5. Feature Relationships

- `key_rate` is negatively correlated with `qber`
- `key_rate` is positively correlated with `photon_rate`
- `retransmit` correlates with `packet_loss`
- `sync_offset` affects both quantum and classical stability

These relationships are enforced statistically during generation.

---

## 6. Labeling and Ground Truth

- Each row has exactly one scenario label
- Labels are consistent across time within a scenario
- No multi-label or ambiguous states are present

---

## 7. Extensibility

This feature table represents the **baseline V2.0 schema**.

Future versions may extend:
- Additional quantum observables
- Host-level system indicators
- Derived temporal features

Backward compatibility will be preserved where possible.

---

## 8. Summary

- Total features (excluding metadata): **9**
- Layers: Quantum + Classical
- Time resolution: **1 second**
- Designed for cross-layer ML-based security analysis
